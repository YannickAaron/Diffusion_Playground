__version__ = '0.15.0.dev20221101'
git_version = 'fc77d372211b5fd6c6c06bfa34a57229c023128c'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
